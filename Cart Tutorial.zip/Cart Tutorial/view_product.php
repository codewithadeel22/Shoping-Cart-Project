<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
    <?php include 'header.php' ?>
    <div class="container">
        <section class="display_product">
            
                    <?php
                    $display_product = mysqli_query($conn, "SELECT * FROM `products`");
                    if (mysqli_num_rows($display_product) > 0) {
                        echo " <table>
                        <thead>
                            <th>Sr No</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Action</th>
                        </thead>
                        <tbody>";
                        $counter = 1; 
                        while ($row = mysqli_fetch_assoc($display_product)) {
                    
                            ?>
                            <tr>
                                <td><?php echo $counter; ?></td>
                                <td><img src="images/<?php echo $row['image'] ?>"
                                         alt="<?php echo $row['name'] ?>" style="width: 6rem;"
                                    /></td>
                                <td><?php echo $row['name'] ?></td>
                                <td><?php echo $row['price'] ?></td>
                                <td>
                                    <a href="delete.php?delete=<?php echo $row['id'] ?>" 
                                    class="delete_product_btn" 
                                    onclick="return confirm('Are You Sure You Want To Delete This Product');">
                                    <i class="fas fa-trash"></i></a>
                                    <a href="update.php?edit=<?php echo $row['id'] ?>"
                                    class="update_product_btn">
                                    <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php
                            $counter++; 
                        }
                    } else {
                        echo "<div class='empty_text'>No products available</div>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </div>
</body>
</html>
