<?php
include 'connect.php';

function sanitizeInput($conn, $input) {
    return mysqli_real_escape_string($conn, htmlspecialchars(trim($input)));
}

function displayCartProducts($conn) {
    $select_cart_products = mysqli_query($conn, "SELECT * FROM `cart`");
    echo "<table>
            <thead>
                <th>Product Name</th>
                <th>Quantity</th>
                <!-- Add more columns as needed -->
            </thead>
            <tbody>";
    
    while($fetch_cart_products = mysqli_fetch_assoc($select_cart_products)){
        echo "<tr>
                <td>" . htmlspecialchars($fetch_cart_products['name']) . "</td>
                <td>{$fetch_cart_products['quantity']}</td>
              </tr>";
        // Add more rows or columns as needed
    }
    
    echo "</tbody></table>";
}

if(isset($_POST['checkout_submit'])){
    $customer_name = sanitizeInput($conn, $_POST['customer_name']);
    $customer_email = filter_var($_POST['customer_email'], FILTER_VALIDATE_EMAIL);
    $shipping_address = sanitizeInput($conn, $_POST['shipping_address']);

    if(empty($customer_name) || empty($customer_email) || empty($shipping_address)) {
        echo "<script>alert('Please fill in all required fields.');</script>";
    } else {
        try {
            $conn->begin_transaction();

            $insert_order_query = $conn->prepare("INSERT INTO `orders` (customer_name, customer_email, shipping_address) VALUES (?, ?, ?)");
            $insert_order_query->bind_param("sss", $customer_name, $customer_email, $shipping_address);

            if (!$insert_order_query->execute()) {
                throw new Exception("Error inserting order data: " . $insert_order_query->error);
            }

            $order_id = $conn->insert_id;

            $select_cart_products = mysqli_query($conn, "SELECT * FROM `cart`");
            while($fetch_cart_products = mysqli_fetch_assoc($select_cart_products)){
                $product_id = $fetch_cart_products['product_id'];
                $quantity = $fetch_cart_products['quantity'];

                $update_product_query = mysqli_query($conn, "UPDATE `products` SET quantity = quantity - $quantity WHERE id = $product_id");

                if (!$update_product_query) {
                    throw new Exception("Error updating product quantity: " . mysqli_error($conn));
                }

                $insert_order_details_query = $conn->prepare("INSERT INTO `order_details` (order_id, product_id, quantity) VALUES (?, ?, ?)");
                $insert_order_details_query->bind_param("iii", $order_id, $product_id, $quantity);

                if (!$insert_order_details_query->execute()) {
                    throw new Exception("Error inserting order details: " . $insert_order_details_query->error);
                }
            }

            mysqli_query($conn, "DELETE FROM `cart`");

            $conn->commit();
            echo "<script>alert('Order placed successfully!');</script>";
        } catch (Exception $e) {
            $conn->rollback();
            echo "<script>alert('Error placing order. Please try again. Error: " . $e->getMessage() . "');</script>";
            error_log("Error: " . $e->getMessage());
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page_Project</title>
    <!-- Include your CSS stylesheets and other necessary links here -->
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <section class="checkout_form">
        <h1 class="heading">Checkout</h1>
        <form action="" method="post">
            <!-- Add form fields for customer information -->
            <label for="customer_name">Name:</label>
            <input type="text" name="customer_name" required>

            <label for="customer_email">Email:</label>
            <input type="email" name="customer_email" required>

            <label for="shipping_address">Shipping Address:</label>
            <textarea name="shipping_address" required></textarea>

            <!-- Display order summary -->
            <h2>Order Summary</h2>
            <?php displayCartProducts($conn); ?>

           

            <input type="submit" class="checkout_submit" value="Place Order" name="checkout_submit">
        </form>
    </section>
</div>

</body>
</html>
