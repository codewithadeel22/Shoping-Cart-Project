<?php
include 'connect.php';

if(isset($_POST['update_product_quantity'])){
    $update_value = mysqli_real_escape_string($conn, $_POST['update_quantity']);
    $update_id = mysqli_real_escape_string($conn, $_POST['update_quantity_id']);
    $update_quantity_query = mysqli_query($conn, "UPDATE `cart` SET quantity = $update_value WHERE id = $update_id");

    if($update_quantity_query){
        header('location: cart.php');
        exit(); 
    }
}

if(isset($_GET['remove'])){
    $remove_id = mysqli_real_escape_string($conn, $_GET['remove']);
    echo "
        <script>
            var confirmDelete = confirm('Are you sure you want to remove this item from the cart?');
            if(confirmDelete){
                window.location.href='cart.php?confirmed_remove=$remove_id';
            } else {
                window.location.href='cart.php';
            }
        </script>";
}

if(isset($_GET['confirmed_remove'])){
    $remove_id = mysqli_real_escape_string($conn, $_GET['confirmed_remove']);
    mysqli_query($conn, "DELETE FROM `cart` WHERE id = $remove_id");
}

if(isset($_GET['delete_all'])){
    echo "
        <script>
            var confirmDeleteAll = confirm('Are you sure you want to remove all items from the cart?');
            if(confirmDeleteAll){
                window.location.href='delete_all.php';
            } else {
                window.location.href='cart.php';
            }
        </script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart Page_Project</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<?php include 'header.php' ?>
<div class="container">
    <section class="shoping_cart">
        <h1 class="heading">
            My Cart
        </h1>
        <table>
            <?php
            $select_cart_products = mysqli_query($conn, "SELECT * FROM `cart`");
            $grand_total = 0;
            if (mysqli_num_rows($select_cart_products) > 0) {
                echo "<thead>
                    <th>S No</th>
                    <th>Product Name</th>
                    <th>Product Image</th>
                    <th>Product Price</th>
                    <th>Product Quantity</th>
                    <th>Total Price</th>
                    <th>Action</th>
                </thead>
                <tbody>";
                $num = 1; 
                while($fetch_cart_products = mysqli_fetch_assoc($select_cart_products)){
                    $total_price = $fetch_cart_products['price'] * $fetch_cart_products['quantity'];
                    $grand_total += $total_price;
            ?>
            <tr>
                <td><?php echo $num++; ?></td>
                <td><?php echo htmlspecialchars($fetch_cart_products['name']); ?></td>
                <td>
                    <img src="images/<?php echo htmlspecialchars($fetch_cart_products['image']); ?>" alt="" style="width: 6rem;">
                </td>
                <td><?php echo $fetch_cart_products['price']; ?></td>
                <td>
                    <form action="" method="post">
                        <input type="hidden" value="<?php echo $fetch_cart_products['id']; ?>" name="update_quantity_id">
                        <div class="quantity_box">
                            <input name="update_quantity" type="number" min="1" value="<?php echo $fetch_cart_products['quantity']; ?>">
                            <input type="submit" class="update_quantity" value="update" name="update_product_quantity">
                        </div>
                    </form>
                </td>
                <td><?php echo number_format($total_price); ?></td>
                <td>
                    <a href="cart.php?remove=<?php echo $fetch_cart_products['id']?>" class="remove_icon_link">
                        <i class="fas fa-trash"></i>Remove
                    </a>
                </td>
            </tr>
            <?php
                }
                echo "</tbody>";
            } else {
                echo "<tr><td colspan='7'>No products</td></tr>";
            }
            ?>
        </table>
        <div class="table_bottom">
            <a href="shop_products.php" class="bottom_btn">Continue Shopping</a>
            <h3 class="bottom_btn">
                Grand Total: <span><?php echo number_format($grand_total); ?>/-</span>
            </h3>
            <a href="checkout.php" class="bottom_btn">Proceed To Check Out</a>
        </div>
        <a href="delete_all.php" class="delete_all_btn" onclick="return confirm('Are you sure you want to delete all items from the cart?');">
            <i class="fas fa-trash"></i>Delete All
        </a>
    </section>
</div>
</body>
</html>
