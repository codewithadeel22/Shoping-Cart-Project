<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Heading Cart</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<header class="header">
    <div class="header_body">
        <a href="index.php" class="logo">MyShoping<span class="cart_text"><sub>Cart</sub></span></a>
        <nav class="navbar">
            <a href="index.php" class="navbar_items">Add Products</a>
            <a href="view_product.php" class="navbar_items">View Products</a>
            <a href="shop_products.php" class="navbar_items">Shopit</a>
        </nav>
        <?php
        $select_product=mysqli_query($conn, "SELECT * FROM `cart`")or die('query failed');
        $row_count=mysqli_num_rows($select_product);
        
        ?>
      <a href="cart.php" class="cart">
    <i class="fas fa-shopping-cart" ></i>
    <span class="cart_numbers" style="position: relative; bottom: 13px; right:5px"><?php echo $row_count ?></span>
</a>

    </div>
</header>

</body>
</html>
