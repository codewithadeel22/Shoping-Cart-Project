<?php
include 'connect.php';

$delete_all_query = mysqli_query($conn, "DELETE FROM `cart`");

if ($delete_all_query) {
    echo "All items have been removed from the cart successfully.<br>";
    echo '<a href="index.php">Continue Shopping</a>'; // Replace "index.php" with the actual page you want to redirect to.
    exit();
} else {
    echo "Error deleting all items from the cart: " . mysqli_error($conn);
}
?>
