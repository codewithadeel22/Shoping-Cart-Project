<?php
include 'connect.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $edit_query = mysqli_query($conn, "SELECT * FROM `products` WHERE id=$edit_id");
    
    if (mysqli_num_rows($edit_query) > 0) {
        $fetch_data = mysqli_fetch_assoc($edit_query);
        
        if (isset($_POST['update_product'])) {
            $update_product_id = $_POST['update_product_id'];
            $update_product_name = mysqli_real_escape_string($conn, $_POST['update_product_name']);
            $update_product_price = mysqli_real_escape_string($conn, $_POST['update_product_price']);
            
            $update_product_image = '';
            if ($_FILES['update_product_image']['name'] != '') {
                $target_dir = 'images/';
                $target_file = $target_dir . basename($_FILES['update_product_image']['name']);
                move_uploaded_file($_FILES['update_product_image']['tmp_name'], $target_file);
                $update_product_image = basename($_FILES['update_product_image']['name']);
            } else {
                $update_product_image = $fetch_data['image'];
            }

            $update_query = "UPDATE `products` SET 
                             `name`='$update_product_name', 
                             `price`='$update_product_price', 
                             `image`='$update_product_image' 
                             WHERE `id`='$update_product_id'";
            
            if (mysqli_query($conn, $update_query)) {
                echo '<p class="success_msg">Product updated successfully!</p>';
                header('Location: view_product.php'); 
                exit();
            } else {
                echo '<p class="error_msg">Error updating product: ' . mysqli_error($conn) . '</p>';
            }
        }
        ?>
        
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Update Products</title>
            <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
            <link rel="stylesheet" href="css/style.css"/>
        </head>
        <body>
          
            <?php include 'header.php' ?>
            <section class="edit_container">
              <h1 class="heading_update">Update Products</h1>
                <form action="" class="update_product product_container_box" method="post" enctype="multipart/form-data">
                <img src="images/<?php echo $fetch_data['image']; ?>" alt="Product Image" style="width: 12rem; display: block; margin: 0 auto;">

                    <input type="hidden" name="update_product_id" value="<?php echo $fetch_data['id']; ?>">
                    <input type="text" name="update_product_name" class="input_fields fields" value="<?php echo $fetch_data['name']; ?>" required>
                    <input type="number" name="update_product_price" class="input_fields fields" value="<?php echo $fetch_data['price']; ?>" required>
                    <input type="file" name="update_product_image" class="input_fields fields" required accept="image/png,image/jpeg">
                    <div class="btns">
                        <input type="submit" name="update_product" class="edit_btn" value="Update Product">
                        <input type="reset" id="close-edit" value="Cancel" class="cancel_btn">
                    </div>
                </form>
               
            </section>
        </body>
        </html>
        
        <?php
    }
}
?>
